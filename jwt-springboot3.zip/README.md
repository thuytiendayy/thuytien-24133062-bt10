# JWT với Spring Boot 3 / Security 6

| Thư mục | Mô tả |
|---|---|
| `jwt-jjwt/`   | Bài tập đúng theo bài giảng – dùng thư viện **JJWT 0.12.6** |
| `jwt-nimbus/` | Cùng project, thay JJWT bằng **Nimbus JOSE + JWT 9.41.2** |

Hai project chỉ khác nhau ở 4 chỗ: `pom.xml`, `services/JwtService.java`, `exceptions/GlobalExceptionHandler.java`
và 2 class mới `InvalidJwtException`, `ExpiredJwtTokenException` (chỉ có ở bản Nimbus).

## Chạy
1. Cần JDK 17+, Maven, MySQL (database tự tạo: `jwt_springboot3`).
2. Sửa user/password MySQL trong `application.properties` (hoặc đặt biến môi trường `DB_USER`, `DB_PASSWORD`).
3. `mvn spring-boot:run` → http://localhost:8005  (chạy 1 project tại một thời điểm, cùng cổng 8005).

## Test (Postman hoặc curl)
```bash
# 1. Đăng ký
curl -X POST localhost:8005/auth/signup -H "Content-Type: application/json" \
  -d '{"email":"trungnh@hcmute.edu.vn","password":"123456","fullName":"Nguyễn Hữu Trung"}'

# 2. Đăng nhập -> nhận token
curl -X POST localhost:8005/auth/login -H "Content-Type: application/json" \
  -d '{"email":"trungnh@hcmute.edu.vn","password":"123456"}'

# 3. Gọi API bảo vệ (không token => 403; có token => 200)
curl localhost:8005/users/me -H "Authorization: Bearer <TOKEN>"
curl localhost:8005/users/    -H "Authorization: Bearer <TOKEN>"

# 4. Token sai => 401 (ProblemDetail JSON)
curl localhost:8005/users/me -H "Authorization: Bearer dfdfdfdf"
```
Demo Ajax: mở http://localhost:8005/login → đăng nhập → chuyển sang `/user/profile`.

## JJWT ↔ Nimbus
| Việc | JJWT | Nimbus |
|---|---|---|
| Build claims | `Jwts.builder().subject().issuedAt().expiration()` | `new JWTClaimsSet.Builder().subject().issueTime().expirationTime()` |
| Header | tự sinh theo `signWith` | `new JWSHeader.Builder(JWSAlgorithm.HS256).type(JOSEObjectType.JWT)` |
| Ký | `.signWith(key, Jwts.SIG.HS256).compact()` | `new SignedJWT(header, claims).sign(new MACSigner(keyBytes))` → `serialize()` |
| Parse + verify | `Jwts.parser().verifyWith(key).build().parseSignedClaims(t)` | `SignedJWT.parse(t)` → `verify(new MACVerifier(keyBytes))` |
| Kiểm tra `exp` | tự động (ném `ExpiredJwtException`) | **tự kiểm tra** `claims.getExpirationTime()` (hoặc dùng `DefaultJWTClaimsVerifier`) |
| Kiểu key | `SecretKey` (`Keys.hmacShaKeyFor`) | `byte[]` |
| Ngoại lệ | `JwtException`, `SignatureException`, `ExpiredJwtException` | `ParseException`, `JOSEException` → bọc thành exception riêng |

## Các lỗi trong code bài giảng đã sửa
- `buildToken` hard-code hết hạn 30 giờ → dùng `security.jwt.expiration-time` (1 giờ).
- Filter inject `HandlerExceptionResolver` không có `@Qualifier("handlerExceptionResolver")` → có thể lỗi nhiều bean cùng kiểu.
- Token sai định dạng trả 500 → nay trả 401; hết hạn/chữ ký sai 401 đúng theo bảng ở slide 30 (code gốc để 403).
- Entity: `images` nullable=false nhưng `signup` không set → lỗi insert; nay có ảnh mặc định `/images/default.svg`.
- `password` hash không còn bị trả ra JSON (`@JsonIgnore`).
- `mainjs.js`: `error: function()` dùng biến `e` chưa khai báo; trang login luôn gọi `/users/me` và hiện alert → chỉ gọi khi có `#profile`. Dùng `.text()` thay `.html()` để tránh XSS.
- Thêm `.cors(Customizer.withDefaults())` để bean CORS thực sự có hiệu lực; thêm `/error` vào permitAll.
- Secret key trong repo là khoá mẫu: **đổi khoá** (`openssl rand -base64 32`) hoặc đặt biến môi trường `JWT_SECRET`.
