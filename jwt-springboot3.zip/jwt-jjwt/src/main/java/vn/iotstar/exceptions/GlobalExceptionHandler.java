package vn.iotstar.exceptions;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AccountStatusException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.security.SignatureException;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    public ProblemDetail handleSecurityException(Exception exception) {
        exception.printStackTrace(); // TODO: đẩy sang công cụ logging/observability

        if (exception instanceof BadCredentialsException)
            return build(401, exception, "The username or password is incorrect");
        if (exception instanceof AccountStatusException)
            return build(403, exception, "The account is locked");
        if (exception instanceof AccessDeniedException)
            return build(403, exception, "You are not authorized to access this resource");
        if (exception instanceof ExpiredJwtException)            // phải đặt trước JwtException
            return build(401, exception, "The JWT token has expired");
        if (exception instanceof SignatureException)
            return build(401, exception, "The JWT signature is invalid");
        if (exception instanceof JwtException)                   // token sai định dạng, v.v.
            return build(401, exception, "The JWT token is invalid");

        return build(500, exception, "Unknown internal server error.");
    }

    private ProblemDetail build(int status, Exception ex, String description) {
        ProblemDetail detail = ProblemDetail.forStatusAndDetail(HttpStatusCode.valueOf(status), ex.getMessage());
        detail.setProperty("description", description);
        return detail;
    }
}
