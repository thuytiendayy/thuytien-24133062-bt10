package vn.iotstar.exceptions;

/** JWT hợp lệ về chữ ký nhưng đã hết hạn (claim exp). */
public class ExpiredJwtTokenException extends InvalidJwtException {
    private static final long serialVersionUID = 1L;

    public ExpiredJwtTokenException(String message) { super(message); }
}
