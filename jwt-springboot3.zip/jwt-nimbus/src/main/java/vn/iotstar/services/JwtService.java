package vn.iotstar.services;

import java.text.ParseException;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import vn.iotstar.exceptions.ExpiredJwtTokenException;
import vn.iotstar.exceptions.InvalidJwtException;

/** JwtService dùng Nimbus JOSE + JWT (thay cho JJWT). API công khai giữ nguyên. */
@Service
public class JwtService {

    @Value("${security.jwt.secret-key}")
    private String secretKey;

    @Value("${security.jwt.expiration-time}")
    private long jwtExpiration;

    public String extractUsername(String token) {
        return extractClaim(token, JWTClaimsSet::getSubject);
    }

    public <T> T extractClaim(String token, Function<JWTClaimsSet, T> claimsResolver) {
        return claimsResolver.apply(extractAllClaims(token));
    }

    public String generateToken(UserDetails userDetails) {
        return generateToken(new HashMap<>(), userDetails);
    }

    public String generateToken(Map<String, Object> extraClaims, UserDetails userDetails) {
        return buildToken(extraClaims, userDetails, jwtExpiration);
    }

    public long getExpirationTime() {
        return jwtExpiration;
    }

    private String buildToken(Map<String, Object> extraClaims, UserDetails userDetails, long expiration) {
        try {
            long now = System.currentTimeMillis();

            // 1. Claims (payload)
            JWTClaimsSet.Builder claims = new JWTClaimsSet.Builder()
                    .subject(userDetails.getUsername())
                    .issueTime(new Date(now))
                    .expirationTime(new Date(now + expiration))
                    .jwtID(UUID.randomUUID().toString());
            extraClaims.forEach(claims::claim);

            // 2. Header
            JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.HS256)
                    .type(JOSEObjectType.JWT)
                    .build();

            // 3. Ký bằng HMAC (secret key) rồi 4. serialize -> header.payload.signature
            SignedJWT signedJWT = new SignedJWT(header, claims.build());
            signedJWT.sign(new MACSigner(getSignInKey()));
            return signedJWT.serialize();
        } catch (JOSEException e) {
            throw new InvalidJwtException("Cannot sign JWT", e);
        }
    }

    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        return username.equals(userDetails.getUsername()) && !isTokenExpired(token);
    }

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {
        return extractClaim(token, JWTClaimsSet::getExpirationTime);
    }

    /** Parse -> kiểm tra alg -> verify chữ ký -> kiểm tra exp -> trả về claims. */
    private JWTClaimsSet extractAllClaims(String token) {
        try {
            SignedJWT jwt = SignedJWT.parse(token);

            // Chặn "alg=none" và các thuật toán không mong muốn
            if (!JWSAlgorithm.HS256.equals(jwt.getHeader().getAlgorithm())) {
                throw new InvalidJwtException("Unsupported JWT algorithm");
            }
            if (!jwt.verify(new MACVerifier(getSignInKey()))) {
                throw new InvalidJwtException("The JWT signature is invalid");
            }
            JWTClaimsSet claims = jwt.getJWTClaimsSet();
            Date exp = claims.getExpirationTime();
            if (exp == null || exp.before(new Date())) {
                throw new ExpiredJwtTokenException("The JWT token has expired");
            }
            return claims;
        } catch (ParseException e) {
            throw new InvalidJwtException("Invalid compact JWT string", e);
        } catch (JOSEException e) {
            throw new InvalidJwtException("Cannot verify JWT", e);
        }
    }

    private byte[] getSignInKey() {
        return Base64.getDecoder().decode(secretKey);
    }
}
